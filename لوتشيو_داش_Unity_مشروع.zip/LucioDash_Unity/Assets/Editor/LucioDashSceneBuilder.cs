#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace LucioDash.Editor
{
    /// <summary>
    /// يبني مشروع لوتشيو داش كاملاً بنقرة واحدة:
    /// القيم/الوسوم، خريطة URP، المواد، الـPrefabs، المشهد، والواجهة.
    /// القائمة: Lucio Dash → Build Scene (كامل)
    /// </summary>
    public static class LucioDashSceneBuilder
    {
        const string MENU = "Lucio Dash/Build Scene (كامل)";

        [MenuItem(MENU, priority = 0)]
        public static void BuildAll()
        {
            EnsureTags();
            EnsureConfig();
            EnsureURP();
            var mats = EnsureMaterials();
            var prefabs = EnsurePrefabs(mats);
            BuildScene(mats, prefabs);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("✅ تم بناء مشروع لوتشيو داش بالكامل. اضغط Play للتجربة.");
        }

        [MenuItem("Lucio Dash/Clear Save (مسح الحفظ)", priority = 100)]
        public static void ClearSave() { SaveManager.ResetAll(); Debug.Log("تم مسح الحفظ."); }

        // ───────────────────────── الوسوم ─────────────────────────
        static void EnsureTags()
        {
            EnsureTag("Coin");
            EnsureTag("Obstacle");
            // "Player" موجود افتراضياً
        }

        static void EnsureTag(string tag)
        {
            var assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
            if (assets == null || assets.Length == 0) return;
            var so = new SerializedObject(assets[0]);
            var prop = so.FindProperty("tags");
            for (int i = 0; i < prop.arraySize; i++)
                if (prop.GetArrayElementAtIndex(i).stringValue == tag) return;
            prop.InsertArrayElementAtIndex(prop.arraySize);
            prop.GetArrayElementAtIndex(prop.arraySize - 1).stringValue = tag;
            so.ApplyModifiedProperties();
        }

        // ───────────────────────── الإعدادات ─────────────────────────
        const string CFG_PATH = "Assets/ScriptableObjects/GameConfig.asset";

        static GameConfig EnsureConfig()
        {
            var cfg = AssetDatabase.LoadAssetAtPath<GameConfig>(CFG_PATH);
            if (cfg == null)
            {
                cfg = ScriptableObject.CreateInstance<GameConfig>();
                AssetDatabase.CreateAsset(cfg, CFG_PATH);
            }
            return cfg;
        }

        // ───────────────────────── URP ─────────────────────────
        const string URP_PATH = "Assets/ScriptableObjects/URPAsset.asset";

        static void EnsureURP()
        {
            if (GraphicsSettings.defaultRenderPipeline != null) return;
            var urpType = Type.GetType("UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset, Unity.RenderPipelines.Universal.Runtime");
            if (urpType == null) { Debug.Log("URP غير موجود — سيُستخدم البايبلاين الافتراضي."); return; }
            var asset = ScriptableObject.CreateInstance(urpType) as RenderPipelineAsset;
            if (asset == null) return;
            // ضبط حقول الأداء عبر الانعكاس
            SetProp(asset, "renderScale", 1.0f);
            SetProp(asset, "shadowDistance", 60f);
            SetProp(asset, "msaaSampleCount", 2);
            SetProp(asset, "supportsHDR", false);
            AssetDatabase.CreateAsset(asset, URP_PATH);
            GraphicsSettings.defaultRenderPipeline = asset;
        }

        static void SetProp(object obj, string name, object value)
        {
            try
            {
                var p = obj.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
                if (p != null && p.CanWrite) p.SetValue(obj, value);
            }
            catch { }
        }

        // ───────────────────────── المواد ─────────────────────────
        class Mats
        {
            public Material grass, road, coin, obstacle, magnet, star, player, enemy, sky;
        }

        static Shader BestShader()
        {
            var s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("Standard");
            return s ?? Shader.Find("Diffuse");
        }

        static Material NewMat(Color c, float metallic = 0f, float smooth = 0.5f)
        {
            var m = new Material(BestShader());
            m.color = c;
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
            return m;
        }

        static Mats EnsureMaterials()
        {
            var m = new Mats();
            m.grass = SaveMat("grass", NewMat(new Color(0.31f, 0.53f, 0.21f), 0, 0.9f));
            m.road = SaveMat("road", NewMat(new Color(0.61f, 0.48f, 0.28f), 0, 0.94f));
            m.coin = SaveMat("coin", NewMat(new Color(1f, 0.78f, 0.1f), 0.85f, 0.25f));
            m.obstacle = SaveMat("obstacle", NewMat(new Color(0.55f, 0.35f, 0.17f), 0, 0.85f));
            m.magnet = SaveMat("magnet", NewMat(new Color(0.91f, 0.30f, 0.24f), 0.3f, 0.4f));
            m.star = SaveMat("star", NewMat(new Color(0.20f, 0.60f, 0.86f), 0.6f, 0.2f));
            m.player = SaveMat("player", NewMat(new Color(0.20f, 0.55f, 0.85f), 0.1f, 0.5f));
            m.enemy = SaveMat("enemy", NewMat(new Color(0.36f, 0.61f, 0.23f), 0.1f, 0.5f));
            m.sky = SaveMat("sky", NewMat(new Color(0.45f, 0.70f, 0.90f)));
            return m;
        }

        static Material SaveMat(string name, Material m)
        {
            const string dir = "Assets/Materials";
            if (!AssetDatabase.IsValidFolder(dir)) AssetDatabase.CreateFolder("Assets", "Materials");
            var path = dir + "/" + name + ".mat";
            var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing != null) { DestroyImmediate(m); return existing; }
            AssetDatabase.CreateAsset(m, path);
            return m;
        }

        // ───────────────────────── الـPrefabs ─────────────────────────
        class Prefabs
        {
            public GameObject coin, obstacle, magnet, star;
        }

        static Prefabs EnsurePrefabs(Mats mats)
        {
            var p = new Prefabs();
            p.coin = SavePrefab("Coin", MakeCoin(mats));
            p.obstacle = SavePrefab("Obstacle", MakeObstacle(mats));
            p.magnet = SavePrefab("Magnet", MakePowerUp(mats.magnet, true));
            p.star = SavePrefab("Star", MakePowerUp(mats.star, false));
            return p;
        }

        const string PF = "Assets/Prefabs";

        static GameObject SavePrefab(string name, GameObject tmp)
        {
            if (!AssetDatabase.IsValidFolder(PF)) AssetDatabase.CreateFolder("Assets", "Prefabs");
            var path = PF + "/" + name + ".prefab";
            var existing = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (existing != null) { DestroyImmediate(tmp); return existing; }
            var prefab = PrefabUtility.SaveAsPrefabAsset(tmp, path);
            DestroyImmediate(tmp);
            return prefab;
        }

        static GameObject MakeCoin(Mats m)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            go.name = "Coin";
            go.transform.localScale = new Vector3(0.6f, 0.08f, 0.6f);
            go.GetComponent<Renderer>().sharedMaterial = m.coin;
            go.GetComponent<Collider>().isTrigger = true;
            go.tag = "Coin";
            return go;
        }

        static GameObject MakeObstacle(Mats m)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "Obstacle";
            go.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
            go.GetComponent<Renderer>().sharedMaterial = m.obstacle;
            var col = go.GetComponent<Collider>(); col.isTrigger = true;
            go.tag = "Obstacle";
            go.AddComponent<Obstacle>();
            return go;
        }

        static GameObject MakePowerUp(Material mat, bool isMagnet)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name = isMagnet ? "Magnet" : "Star";
            go.transform.localScale = Vector3.one * 0.5f;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            go.GetComponent<Collider>().isTrigger = true;
            var pu = go.AddComponent<PowerUp>(); pu.isMagnet = isMagnet;
            return go;
        }

        // ───────────────────────── المشهد ─────────────────────────
        static void BuildScene(Mats mats, Prefabs prefabs)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var cfg = EnsureConfig();

            // السماء والضباب
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.81f, 0.91f, 0.96f);
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 30f;
            RenderSettings.fogEndDistance = 110f;
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.7f, 0.78f, 0.85f);

            // الكاميرا
            var camGO = new GameObject("Main Camera");
            var cam = camGO.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.45f, 0.70f, 0.90f);
            cam.fieldOfView = 62f;
            camGO.AddComponent<AudioListener>();
            var camFollow = camGO.AddComponent<CameraFollow>();
            camFollow.config = cfg;
            camGO.tag = "MainCamera";

            // الإضاءة
            var sun = new GameObject("Sun");
            var dl = sun.AddComponent<Light>();
            dl.type = LightType.Directional;
            dl.color = new Color(1f, 0.95f, 0.80f);
            dl.intensity = 1.6f;
            dl.shadows = LightShadows.Soft;
            sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            var fillGO = new GameObject("Fill");
            var fl = fillGO.AddComponent<Light>();
            fl.type = LightType.Directional;
            fl.color = new Color(0.80f, 0.88f, 1f); fl.intensity = 0.4f;
            fillGO.transform.rotation = Quaternion.Euler(-30f, 20f, 0f);

            // الأرضية + الطريق
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Ground"; ground.transform.localScale = new Vector3(4, 1, 30);
            ground.transform.position = new Vector3(0, 0, 0);
            ground.GetComponent<Renderer>().sharedMaterial = mats.grass;
            var scroller = ground.AddComponent<GroundScroller>();
            scroller.groundRenderer = ground.GetComponent<Renderer>();

            var road = GameObject.CreatePrimitive(PrimitiveType.Plane);
            road.name = "Road"; road.transform.localScale = new Vector3(0.74f, 1, 30);
            road.transform.position = new Vector3(0, 0.01f, 0);
            road.GetComponent<Renderer>().sharedMaterial = mats.road;

            // الديكور الجانبي
            var decor = new List<Transform>();
            for (int i = 0; i < 8; i++)
            {
                int side = (i % 2 == 0) ? -1 : 1;
                var d = GameObject.CreatePrimitive(i % 2 == 0 ? PrimitiveType.Cylinder : PrimitiveType.Cube);
                d.name = "Decor" + i;
                d.transform.localScale = (i % 2 == 0 ? new Vector3(0.5f, 1.5f, 0.5f) : new Vector3(0.8f, 1.2f, 0.8f));
                d.transform.position = new Vector3(side * 7f, 0.6f, -i * 10f);
                d.GetComponent<Renderer>().sharedMaterial = i % 3 == 0 ? mats.grass : mats.obstacle;
                decor.Add(d.transform);
            }
            scroller.decor = decor.ToArray();

            // اللاعب
            var playerGO = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            playerGO.name = "Player"; playerGO.tag = "Player";
            playerGO.transform.position = new Vector3(0, 1f, 0);
            playerGO.GetComponent<Renderer>().sharedMaterial = mats.player;
            var rb = playerGO.AddComponent<Rigidbody>();
            rb.isKinematic = true; rb.useGravity = false; rb.constraints = RigidbodyConstraints.FreezeRotation;
            var pcol = playerGO.GetComponent<Collider>(); pcol.isTrigger = false;
            var modelRoot = new GameObject("ModelRoot"); modelRoot.transform.SetParent(playerGO.transform, false);
            var pc = playerGO.AddComponent<PlayerController>();
            pc.modelRoot = modelRoot;
            var lc = playerGO.AddComponent<LucioCharacter>();
            lc.controller = pc;

            // الخصم
            var enemyGO = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            enemyGO.name = "Krench"; enemyGO.transform.position = new Vector3(0, 1f, -9f);
            enemyGO.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
            enemyGO.GetComponent<Renderer>().sharedMaterial = mats.enemy;
            var enemy = enemyGO.AddComponent<EnemyAI>();
            enemy.target = playerGO.transform;

            // ObjectPooler
            var poolGO = new GameObject("ObjectPooler");
            var pooler = poolGO.AddComponent<ObjectPooler>();
            pooler.pools = new List<ObjectPooler.Pool>
            {
                new ObjectPooler.Pool { id = "Coin", prefab = prefabs.coin, initialSize = 24, maxSize = 80 },
                new ObjectPooler.Pool { id = "Obstacle", prefab = prefabs.obstacle, initialSize = 10, maxSize = 30 },
                new ObjectPooler.Pool { id = "Magnet", prefab = prefabs.magnet, initialSize = 2, maxSize = 6 },
                new ObjectPooler.Pool { id = "Star", prefab = prefabs.star, initialSize = 2, maxSize = 6 },
            };

            // Spawner
            var spGO = new GameObject("Spawner");
            var spawner = spGO.AddComponent<Spawner>();
            spawner.pooler = pooler;

            // GameManager
            var gmGO = new GameObject("GameManager");
            var gm = gmGO.AddComponent<GameManager>();
            gm.config = cfg; gm.player = pc; gm.spawner = spawner; gm.enemy = enemy; gm.cameraFollow = camFollow;
            camFollow.target = playerGO.transform;

            // Audio + Ads
            var audioGO = new GameObject("AudioManager");
            audioGO.AddComponent<AudioManager>();
            var adsGO = new GameObject("AdMobManager");
            adsGO.AddComponent<AdMobManager>();

            // ── الواجهة ──
            BuildUI(gm);

            camFollow.target = playerGO.transform;

            // حفظ المشهد
            const string sceneDir = "Assets/Scenes";
            if (!AssetDatabase.IsValidFolder(sceneDir)) AssetDatabase.CreateFolder("Assets", "Scenes");
            const string scenePath = sceneDir + "/Main.unity";
            EditorSceneManager.SaveScene(scene, scenePath);
            EditorSceneManager.MarkSceneDirty(scene);
            Debug.Log("تم حفظ المشهد: " + scenePath);
        }

        // ───────────────────────── الواجهة ─────────────────────────
        static void BuildUI(GameManager gm)
        {
            var canvasGO = new GameObject("UI_Canvas");
            var canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGO.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.matchWidthOrHeight = 0.5f;
            canvasGO.AddComponent<GraphicRaycaster>();

            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();

            // ── HUD ──
            var hud = new GameObject("HUD").transform; hud.SetParent(canvasGO.transform, false);
            var hudC = hud.gameObject.AddComponent<HUD>();
            hudC.distText = MkText(hud, "Dist", "0 م", TextAnchor.UpperLeft, new Vector2(40, -20), new Vector2(0, 1));
            hudC.coinsText = MkText(hud, "Coins", "🪙 0", TextAnchor.UpperRight, new Vector2(-40, -20), new Vector2(1, 1));
            hudC.scoreText = MkText(hud, "Score", "0", TextAnchor.UpperCenter, new Vector2(0, -60), new Vector2(0.5f, 1));
            hudC.heartsText = MkText(hud, "Hearts", "❤❤❤", TextAnchor.UpperCenter, new Vector2(0, -20), new Vector2(0.5f, 1));
            hudC.levelText = MkText(hud, "Level", "المستوى 7", TextAnchor.UpperCenter, new Vector2(0, -90), new Vector2(0.5f, 1));
            hudC.comboText = MkText(hud, "Combo", "", TextAnchor.MiddleCenter, new Vector2(0, -200), new Vector2(0.5f, 0.5f), 48, Color.yellow);
            hudC.comboText.gameObject.SetActive(false);
            hudC.toastText = MkText(hud, "Toast", "", TextAnchor.MiddleCenter, new Vector2(0, -300), new Vector2(0.5f, 0.5f), 40, Color.white);
            hudC.toastText.gameObject.SetActive(false);
            // أزرار القدرات
            hudC.magnetBtn = MkButton(hud, "MagnetBtn", "🧲", new Vector2(-160, 80), new Vector2(0, 0));
            hudC.starBtn = MkButton(hud, "StarBtn", "⭐", new Vector2(160, 80), new Vector2(1, 0));
            hudC.magnetBar = MkFill(hud, "MagnetBar", new Vector2(-160, 140), new Vector2(0, 0));
            hudC.starBar = MkFill(hud, "StarBar", new Vector2(160, 140), new Vector2(1, 0));

            // زر الإيقاف (يُربط بـPauseMenuUI)
            var pauseOpenBtn = MkButton(hud, "PauseOpenBtn", "⏸", new Vector2(-40, -40), new Vector2(1, 1));

            // ── MainMenu ──
            var menu = new GameObject("MainMenu").transform; menu.SetParent(canvasGO.transform, false);
            var menuC = menu.gameObject.AddComponent<MainMenuUI>();
            menuC.group = menu.gameObject.AddComponent<CanvasGroup>();
            var title = MkText(menu, "Title", "لوتشيو داش", TextAnchor.MiddleCenter, new Vector2(0, 100), new Vector2(0.5f, 0.5f), 72, Color.white);
            menuC.bestText = MkText(menu, "Best", "أفضل: 0", TextAnchor.MiddleCenter, new Vector2(0, 0), new Vector2(0.5f, 0.5f));
            menuC.coinsText = MkText(menu, "CoinsM", "🪙 0", TextAnchor.MiddleCenter, new Vector2(0, -50), new Vector2(0.5f, 0.5f));
            menuC.playBtn = MkButton(menu, "PlayBtn", "▶ لعب", new Vector2(0, -160), new Vector2(0.5f, 0.5f), 320, 90);
            menuC.storeBtn = MkButton(menu, "StoreBtn", "🛒 متجر", new Vector2(0, -270), new Vector2(0.5f, 0.5f), 320, 70);
            menuC.muteBtn = MkButton(menu, "MuteBtn", "🔊", new Vector2(40, 40), new Vector2(1, 1), 80, 80);

            // ── GameOver ──
            var over = new GameObject("GameOver").transform; over.SetParent(canvasGO.transform, false);
            var overC = over.gameObject.AddComponent<GameOverUI>();
            overC.group = over.gameObject.AddComponent<CanvasGroup>();
            MkText(over, "Title", "انتهت اللعبة", TextAnchor.MiddleCenter, new Vector2(0, 200), new Vector2(0.5f, 0.5f), 60, Color.white);
            overC.scoreText = MkText(over, "Score", "0", TextAnchor.MiddleCenter, new Vector2(0, 120), new Vector2(0.5f, 0.5f), 48, Color.yellow);
            overC.bestText = MkText(over, "Best", "أفضل: 0", TextAnchor.MiddleCenter, new Vector2(0, 60), new Vector2(0.5f, 0.5f));
            overC.coinsText = MkText(over, "CoinsG", "🪙 0", TextAnchor.MiddleCenter, new Vector2(0, 10), new Vector2(0.5f, 0.5f));
            overC.reviveBtn = MkButton(over, "ReviveBtn", "🎬 إحياء", new Vector2(0, -80), new Vector2(0.5f, 0.5f), 320, 80);
            overC.restartBtn = MkButton(over, "RestartBtn", "↻ إعادة", new Vector2(0, -180), new Vector2(0.5f, 0.5f), 320, 70);
            overC.homeBtn = MkButton(over, "HomeBtn", "🏠 القائمة", new Vector2(0, -270), new Vector2(0.5f, 0.5f), 320, 70);

            // ── Store ──
            var store = new GameObject("Store").transform; store.SetParent(canvasGO.transform, false);
            var storeC = store.gameObject.AddComponent<StoreUI>();
            storeC.group = store.gameObject.AddComponent<CanvasGroup>();
            MkText(store, "Title", "المتجر", TextAnchor.UpperCenter, new Vector2(0, -60), new Vector2(0.5f, 1), 48, Color.white);
            storeC.coinsText = MkText(store, "Coins", "🪙 0", TextAnchor.UpperCenter, new Vector2(0, -120), new Vector2(0.5f, 1));
            // حاوية بعناصر عمودية
            var content = new GameObject("Content", typeof(RectTransform)).transform;
            content.SetParent(store.transform, false);
            var vlg = content.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 12; vlg.padding = new RectOffset(60, 60, 180, 60);
            vlg.childAlignment = TextAnchor.UpperCenter;
            var fitter = content.gameObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            var contentRT = content.GetComponent<RectTransform>();
            contentRT.anchorMin = Vector2.zero; contentRT.anchorMax = Vector2.one; contentRT.offsetMin = Vector2.zero; contentRT.offsetMax = Vector2.zero;
            storeC.content = content;
            storeC.closeBtn = MkButton(store, "CloseBtn", "✕", new Vector2(-40, -40), new Vector2(1, 1), 80, 80);

            // ── Pause ──
            var pause = new GameObject("PauseMenu").transform; pause.SetParent(canvasGO.transform, false);
            var pauseC = pause.gameObject.AddComponent<PauseMenuUI>();
            pauseC.group = pause.gameObject.AddComponent<CanvasGroup>();
            MkText(pause, "Title", "إيقاف مؤقّت", TextAnchor.MiddleCenter, new Vector2(0, 200), new Vector2(0.5f, 0.5f), 56, Color.white);
            pauseC.resumeBtn = MkButton(pause, "ResumeBtn", "▶ استئناف", new Vector2(0, 60), new Vector2(0.5f, 0.5f), 320, 80);
            pauseC.restartBtn = MkButton(pause, "RestartBtn", "↻ إعادة", new Vector2(0, -40), new Vector2(0.5f, 0.5f), 320, 70);
            pauseC.homeBtn = MkButton(pause, "HomeBtn", "🏠 القائمة", new Vector2(0, -140), new Vector2(0.5f, 0.5f), 320, 70);
            pauseC.muteBtn = MkButton(pause, "MuteBtn", "🔊", new Vector2(40, 40), new Vector2(1, 1), 80, 80);
            pauseC.pauseOpenBtn = pauseOpenBtn;
        }

        // ── مساعدات الواجهة ──
        static Font _font;
        static Font Font()
        {
            if (_font != null) return _font;
            // ابحث عن أي خط مُستورد في Assets أولاً (يدعم العربية إن وُجد، مثل Cairo/Tajawal)
            var guids = AssetDatabase.FindAssets("t:Font");
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                var f = AssetDatabase.LoadAssetAtPath<Font>(path);
                if (f != null && !path.Contains("LegacyRuntime")) { _font = f; return f; }
            }
            // وإلا فالخط الافتراضي (لا يحوي عربية — استورد Cairo.ttf لعرض العربية)
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            return _font;
        }

        static Text MkText(Transform parent, string name, string text, TextAnchor anchor, Vector2 pos, Vector2 pivot, int size = 30, Color? col = null)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            t.text = text; t.font = Font(); t.fontSize = size; t.color = col ?? Color.white;
            t.alignment = anchor; t.raycastTarget = false;
            var rt = t.rectTransform;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = new Vector2(400, 60);
            // ظل بسيط
            var sh = go.AddComponent<Shadow>(); sh.effectColor = new Color(0, 0, 0, 0.6f); sh.effectDistance = new Vector2(2, -2);
            return t;
        }

        static Button MkButton(Transform parent, string name, string label, Vector2 pos, Vector2 pivot, float w = 200, float h = 60)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>(); img.color = new Color(0.10f, 0.14f, 0.20f, 0.85f);
            var b = go.AddComponent<Button>();
            var colors = b.colors; colors.normalColor = new Color(0.15f, 0.20f, 0.30f, 0.9f);
            colors.highlightedColor = new Color(0.22f, 0.30f, 0.45f, 1f); colors.pressedColor = new Color(0.08f, 0.12f, 0.18f, 1f);
            b.colors = colors;
            var rt = b.GetComponent<RectTransform>();
            rt.pivot = pivot; rt.anchoredPosition = pos; rt.sizeDelta = new Vector2(w, h);
            // نص الزر
            var tg = new GameObject("T", typeof(RectTransform)); tg.transform.SetParent(go.transform, false);
            var t = tg.AddComponent<Text>(); t.text = label; t.font = Font(); t.fontSize = 30; t.color = Color.white; t.alignment = TextAnchor.MiddleCenter;
            var trt = t.rectTransform; trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one; trt.offsetMin = trt.offsetMax = Vector2.zero;
            return b;
        }

        static Image MkFill(Transform parent, string name, Vector2 pos, Vector2 pivot)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var img = go.AddComponent<Image>(); img.color = new Color(1f, 0.78f, 0.1f, 0.8f);
            img.type = Image.Type.Filled; img.fillMethod = Image.FillMethod.Horizontal; img.fillAmount = 0f;
            var rt = img.rectTransform; rt.pivot = pivot; rt.anchoredPosition = pos; rt.sizeDelta = new Vector2(120, 10);
            return img;
        }
    }
}
#endif
