using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// الجانب البصري للشخصية: خطوات القدمين، غبار، وإيماءات.
    /// يوضع على جذر النموذج. يقرأ حالة اللاعب من PlayerController.
    /// </summary>
    public class LucioCharacter : MonoBehaviour
    {
        public PlayerController controller;
        public Animator animator;
        public ParticleSystem dustPrefab;
        public float stepInterval = 0.32f;

        float _stepT;

        void Awake()
        {
            if (controller == null) controller = GetComponentInParent<PlayerController>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
        }

        void Update()
        {
            if (GameManager.Instance == null) return;
            bool playing = GameManager.Instance.State == GameState.Playing;
            if (animator != null) animator.SetBool("Run", playing && !controller.IsJumping && !controller.IsSliding);

            if (!playing || controller.IsJumping || controller.IsSliding) return;
            _stepT -= Time.deltaTime;
            if (_stepT <= 0f)
            {
                _stepT = stepInterval / Mathf.Max(0.5f, GameManager.Instance.Speed / GameManager.Instance.config.baseSpeed);
                if (AudioManager.Instance) AudioManager.Instance.PlayFootstep();
                if (dustPrefab != null)
                {
                    var p = Instantiate(dustPrefab, transform.position + Vector3.back * 0.3f, Quaternion.identity);
                    Destroy(p.gameObject, 1f);
                }
            }
        }
    }
}
