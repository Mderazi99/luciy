using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// الخصم كريتشوس: يلاحق من الخلف، يقترب عند كل اصطدام،
    /// ويمسك اللاعب (Game Over) عند استنفاد القلوب.
    /// وضع "الاستفزاز" (Taunt) يظهر عند الاقتراب الشديد.
    /// </summary>
    public class EnemyAI : MonoBehaviour
    {
        public Transform target;            // اللاعب
        public Animator animator;
        public float followLerp = 4f;
        public float tauntProximity = 4f;

        GameConfig _cfg;
        float _curDistance;
        bool _taunting;

        void Awake()
        {
            _cfg = GameManager.Instance.config;
            ResetDistance();
        }

        public void ResetDistance()
        {
            _curDistance = _cfg.enemyBaseDistance;
            UpdatePosition(1f);
        }

        public void ApproachOnHit()
        {
            _curDistance = Mathf.Max(_cfg.enemyCatchDistance * 0.5f, _curDistance - _cfg.enemyApproachOnHit);
            if (animator != null) animator.SetTrigger("Attack");
        }

        /// <summary>يُستدعى كل إطار من GameManager.</summary>
        public void TickChase(float dt)
        {
            UpdatePosition(dt);
            // عند الاقتراب الشديد في وضع الاستفزاز
            bool near = _curDistance < tauntProximity;
            if (near != _taunting)
            {
                _taunting = near;
                if (animator != null) animator.SetBool("Taunt", near);
            }
        }

        void UpdatePosition(float dt)
        {
            if (target == null) return;
            Vector3 p = target.position - Vector3.forward * _curDistance;
            p.x = target.position.x * 0.6f;
            transform.position = Vector3.Lerp(transform.position, p, Mathf.Clamp01(followLerp * dt));
            transform.LookAt(target.position + Vector3.forward * 2f);
        }

        public bool IsCatching => _curDistance <= _cfg.enemyCatchDistance;
    }
}
