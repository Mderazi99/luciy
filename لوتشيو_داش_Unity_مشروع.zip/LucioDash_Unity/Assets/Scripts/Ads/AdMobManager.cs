using System;
using UnityEngine;
#if ADMOB
using GoogleMobileAds.Api;
#endif

namespace LucioDash
{
    /// <summary>
    /// إدارة إعلانات AdMob (Interstitial + Rewarded).
    /// • بدون تعريف ADMOB: يعمل كنسخة احتياطية (الإحياء ينجح فوراً دون إعلان).
    /// • مع تعريف ADMOB + إضافة Google Mobile Ads: إعلانات حقيقية.
    /// استبدل معرّفات الاختبار بمعرّفاتك من AdMob.
    /// </summary>
    public class AdMobManager : MonoBehaviour
    {
        public static AdMobManager Instance { get; private set; }

        [Header("معرّفات الإعلانات (استبدلها بمعرّفاتك)")]
        public string appId = "ca-app-pub-3940256099942544~3347511713";
        public string interstitialId = "ca-app-pub-3940256099942544/1033173712";
        public string rewardedId = "ca-app-pub-3940256099942544/5224354917";

        [Header("كل كم جولة نعرض إعلاناً بينياً؟")]
        public int showEveryGames = 3;

#if ADMOB
        InterstitialAd _interstitial;
        RewardedAd _rewarded;
        bool _init;
#endif

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
#if ADMOB
            Initialize();
#endif
        }
        void OnDestroy() { if (Instance == this) Instance = null; }

#if ADMOB
        void Initialize()
        {
            if (_init) return;
            _init = true;
            MobileAds.Initialize(_ =>
            {
                LoadInterstitial();
                LoadRewarded();
            });
        }

        void LoadInterstitial()
        {
            InterstitialAd.Load(interstitialId, new AdRequest(), (ad, err) =>
            {
                if (err != null || ad == null) return;
                _interstitial = ad;
            });
        }

        void LoadRewarded()
        {
            RewardedAd.Load(rewardedId, new AdRequest(), (ad, err) =>
            {
                if (err != null || ad == null) return;
                _rewarded = ad;
            });
        }
#endif

        /// <summary>يُستدعى عند انتهاء اللعبة: يعرض إعلاناً بينياً كل N جولات.</summary>
        public void NotifyGameOver()
        {
            if (SaveManager.GamesPlayed % showEveryGames != 0) return;
#if ADMOB
            if (_interstitial != null && _interstitial.CanShowAd())
            {
                _interstitial.Show();
                _interstitial = null;
                LoadInterstitial();
            }
#endif
        }

        /// <summary>يعرض إعلاناً بمكافأة ثم يستدعي onReward (إحياء).</summary>
        public void ShowRewardedAd(Action onReward)
        {
#if ADMOB
            if (_rewarded != null && _rewarded.CanShowAd())
            {
                _rewarded.ShowRewardedAd(_ =>
                {
                    onReward?.Invoke();
                    _rewarded = null;
                    LoadRewarded();
                });
                return;
            }
#endif
            // نسخة احتياطية: نفّذ المكافأة مباشرة
            onReward?.Invoke();
        }
    }
}
