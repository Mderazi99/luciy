using UnityEngine;
using UnityEngine.UI;

namespace LucioDash
{
    /// <summary>القائمة الرئيسية: لعب، متجر، كتم، أفضل نتيجة، العملات.</summary>
    public class MainMenuUI : MonoBehaviour
    {
        public CanvasGroup group;
        public Button playBtn, storeBtn, muteBtn;
        public Text bestText, coinsText, titleText;

        void OnEnable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged += StateChanged; }
        void OnDisable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged -= StateChanged; }

        void Start()
        {
            playBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.StartGame(); });
            if (storeBtn) storeBtn.onClick.AddListener(() => { StoreUI.Show(); });
            if (muteBtn) muteBtn.onClick.AddListener(() => { SaveManager.Muted = !SaveManager.Muted; RefreshMute(); if (AudioManager.Instance) AudioManager.Instance.RefreshMute(); });
            Refresh();
        }

        void StateChanged(GameState s) => Refresh();

        void Refresh()
        {
            bool show = GameManager.Instance.State == GameState.Menu;
            if (group) { group.alpha = show ? 1f : 0f; group.blocksRaycasts = show; group.interactable = show; }
            if (bestText) bestText.text = "أفضل: " + SaveManager.BestScore;
            if (coinsText) coinsText.text = "🪙 " + SaveManager.Coins;
            RefreshMute();
        }

        void RefreshMute() { if (muteBtn) muteBtn.GetComponentInChildren<Text>().text = SaveManager.Muted ? "🔇" : "🔊"; }
    }
}
