using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace LucioDash
{
    /// <summary>
    /// المتجر: شراء شخصيات وترقيات باستخدام العملات المحفوظة.
    /// يبني عناصره برمجياً داخل لوحة بـ VerticalLayoutGroup.
    /// </summary>
    public class StoreUI : MonoBehaviour
    {
        public static StoreUI Instance { get; private set; }

        public CanvasGroup group;
        public Transform content;          // VerticalLayoutGroup container
        public Button closeBtn;
        public Text coinsText;
        public Button itemPrefab;          // ززر نموذجي (اختياري)

        [System.Serializable]
        public class StoreItem
        {
            public string id;
            public string label;
            public int price;
            public System.Action onBuy;    // ما يحدث عند الشراء
        }

        readonly List<StoreItem> _items = new List<StoreItem>();

        void Awake()
        {
            Instance = this;
            BuildCatalog();
            if (closeBtn) closeBtn.onClick.AddListener(Hide);
            SetVisible(false);
        }
        void OnDestroy() { if (Instance == this) Instance = null; }

        public static void Show() { if (Instance != null) Instance.Open(); }

        void Open()
        {
            Render();
            SetVisible(true);
        }
        public void Hide()
        {
            SetVisible(false);
            if (AudioManager.Instance) AudioManager.Instance.PlayClick();
        }

        void SetVisible(bool v) { if (group) { group.alpha = v ? 1f : 0f; group.blocksRaycasts = v; group.interactable = v; } }

        void BuildCatalog()
        {
            _items.Add(new StoreItem { id = "char_lucio2", label = "شخصية: لوتشيو المتطوّر", price = 200,
                onBuy = () => { SaveManager.SelectedCharacter = 1; } });
            _items.Add(new StoreItem { id = "char_lucio3", label = "شخصية: لوتشيو الذهبي", price = 500,
                onBuy = () => { SaveManager.SelectedCharacter = 2; } });
            _items.Add(new StoreItem { id = "mag_up", label = "ترقية المغناطيس (+مدة)", price = 150,
                onBuy = () => { SaveManager.MagnetLevel = SaveManager.MagnetLevel + 1; } });
            _items.Add(new StoreItem { id = "star_up", label = "ترقية النجمة (+مدة)", price = 150,
                onBuy = () => { SaveManager.StarLevel = SaveManager.StarLevel + 1; } });
        }

        void Render()
        {
            if (coinsText) coinsText.text = "🪙 " + SaveManager.Coins;
            // إعادة بناء الأزرار
            for (int i = content.childCount - 1; i >= 0; i--) Destroy(content.GetChild(i).gameObject);
            foreach (var it in _items)
            {
                var btn = itemPrefab != null ? Instantiate(itemPrefab, content) : MakeButton();
                bool unlocked = SaveManager.IsUnlocked(it.id);
                btn.GetComponentInChildren<Text>().text = it.label + (unlocked ? "  ✓" : "  — 🪙" + it.price);
                btn.interactable = !unlocked;
                var captured = it;
                btn.onClick.AddListener(() => TryBuy(captured));
            }
        }

        Button MakeButton()
        {
            var go = new GameObject("Item", typeof(RectTransform));
            go.transform.SetParent(content, false);
            var img = go.AddComponent<Image>(); img.color = new Color(0.1f, 0.14f, 0.2f, 0.85f);
            var b = go.AddComponent<Button>();
            var txtGo = new GameObject("T", typeof(RectTransform));
            txtGo.transform.SetParent(go.transform, false);
            var txt = txtGo.AddComponent<Text>();
            txt.alignment = TextAnchor.MiddleCenter; txt.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            txt.color = Color.white; txt.fontSize = 22;
            var rt = txt.rectTransform; rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero;
            return b;
        }

        void TryBuy(StoreItem it)
        {
            if (SaveManager.IsUnlocked(it.id)) return;
            if (!SaveManager.TrySpend(it.price)) { if (GameManager.Instance != null) GameManager.Instance.OnToast?.Invoke("عملات غير كافية"); return; }
            SaveManager.Unlock(it.id);
            it.onBuy?.Invoke();
            SaveManager.Save();
            if (AudioManager.Instance) AudioManager.Instance.PlayPower();
            Render();
        }
    }
}
