using UnityEngine;
using UnityEngine.UI;

namespace LucioDash
{
    /// <summary>شاشة انتهاء اللعبة: النقاط، الأفضل، العملات، إحياء، إعادة، القائمة، المتجر.</summary>
    public class GameOverUI : MonoBehaviour
    {
        public CanvasGroup group;
        public Text scoreText, bestText, coinsText;
        public Button reviveBtn, restartBtn, homeBtn, storeBtn;

        void OnEnable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged += StateChanged; }
        void OnDisable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged -= StateChanged; }

        void Start()
        {
            restartBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.StartGame(); });
            homeBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.BackToMenu(); });
            if (reviveBtn) reviveBtn.onClick.AddListener(RequestRevive);
            if (storeBtn) storeBtn.onClick.AddListener(() => StoreUI.Show());
            SetVisible(false);
        }

        void StateChanged(GameState s)
        {
            if (s == GameState.GameOver) { Fill(); SetVisible(true); }
            else if (s == GameState.Playing) SetVisible(false);
        }

        void Fill()
        {
            if (scoreText) scoreText.text = GameManager.Instance.Score.ToString();
            if (bestText) bestText.text = "أفضل: " + SaveManager.BestScore;
            if (coinsText) coinsText.text = "🪙 " + SaveManager.Coins;
            if (reviveBtn) reviveBtn.gameObject.SetActive(AdMobManager.Instance != null);
        }

        void RequestRevive()
        {
            var ads = AdMobManager.Instance;
            if (ads != null) ads.ShowRewardedAd(() => GameManager.Instance.Revive());
            else GameManager.Instance.Revive();
        }

        void SetVisible(bool v) { if (group) { group.alpha = v ? 1f : 0f; group.blocksRaycasts = v; group.interactable = v; } }
    }
}
