using UnityEngine;
using UnityEngine.UI;

namespace LucioDash
{
    /// <summary>قائمة الإيقاف: استئناف، إعادة، القائمة، كتم الصوت.</summary>
    public class PauseMenuUI : MonoBehaviour
    {
        public CanvasGroup group;
        public Button resumeBtn, restartBtn, homeBtn, muteBtn;
        public Button pauseOpenBtn;   // زر الإيقاف في الـHUD

        void OnEnable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged += StateChanged; }
        void OnDisable() { if (GameManager.Instance) GameManager.Instance.OnStateChanged -= StateChanged; }

        void Start()
        {
            resumeBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.Resume(); });
            restartBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.Resume(); GameManager.Instance.StartGame(); });
            homeBtn.onClick.AddListener(() => { if (AudioManager.Instance) AudioManager.Instance.PlayClick(); GameManager.Instance.Resume(); GameManager.Instance.BackToMenu(); });
            if (muteBtn) muteBtn.onClick.AddListener(() => { SaveManager.Muted = !SaveManager.Muted; RefreshMute(); if (AudioManager.Instance) AudioManager.Instance.RefreshMute(); });
            if (pauseOpenBtn) pauseOpenBtn.onClick.AddListener(() => { if (GameManager.Instance.State == GameState.Playing) GameManager.Instance.Pause(); });
            SetVisible(false);
        }

        void StateChanged(GameState s) => SetVisible(s == GameState.Paused);

        void SetVisible(bool v) { if (group) { group.alpha = v ? 1f : 0f; group.blocksRaycasts = v; group.interactable = v; } }

        void RefreshMute() { if (muteBtn) muteBtn.GetComponentInChildren<Text>().text = SaveManager.Muted ? "🔇" : "🔊"; }
    }
}
