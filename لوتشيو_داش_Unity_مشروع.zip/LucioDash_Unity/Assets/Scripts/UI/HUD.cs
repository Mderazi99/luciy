using UnityEngine;
using UnityEngine.UI;

namespace LucioDash
{
    /// <summary>
    /// واجهة اللعب: المسافة، العملات، النقاط، القلوب، الكومبو،
    /// رسالة عابرة، وأزرار القدرات مع أشرطة الشحن.
    /// </summary>
    public class HUD : MonoBehaviour
    {
        public Text distText, coinsText, scoreText, heartsText, comboText, toastText, levelText;
        public Image magnetBar, starBar, evoBar;
        public Button magnetBtn, starBtn;

        float _toastT;

        void OnEnable()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;
            gm.OnCoinsChanged += CoinsChanged;
            gm.OnScoreChanged += ScoreChanged;
            gm.OnHeartsChanged += HeartsChanged;
            gm.OnComboChanged += ComboChanged;
            gm.OnToast += ShowToast;
            gm.OnPowerChargeChanged += PowerCharge;
        }
        void OnDisable()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;
            gm.OnCoinsChanged -= CoinsChanged;
            gm.OnScoreChanged -= ScoreChanged;
            gm.OnHeartsChanged -= HeartsChanged;
            gm.OnComboChanged -= ComboChanged;
            gm.OnToast -= ShowToast;
            gm.OnPowerChargeChanged -= PowerCharge;
        }

        void Start()
        {
            magnetBtn.onClick.AddListener(() => GameManager.Instance.ActivateMagnet());
            starBtn.onClick.AddListener(() => GameManager.Instance.ActivateStar());
            if (coinsText) coinsText.text = SaveManager.Coins.ToString();
            if (heartsText) heartsText.text = "❤❤❤";
        }

        void Update()
        {
            if (distText) distText.text = Mathf.FloorToInt(GameManager.Instance.Distance) + " م";
            if (scoreText) scoreText.text = GameManager.Instance.Score.ToString();
            if (levelText) levelText.text = "المستوى " + Mathf.FloorToInt(GameManager.Instance.Speed / 2f);

            // أزرار القدرات: جاهزة عند اكتمال الشحن
            bool mReady = GameManager.Instance.MagnetCharge >= 1f && !GameManager.Instance.MagnetActive;
            bool sReady = GameManager.Instance.StarCharge >= 1f && !GameManager.Instance.StarActive;
            if (magnetBtn) magnetBtn.interactable = mReady;
            if (starBtn) starBtn.interactable = sReady;

            if (_toastT > 0) { _toastT -= Time.deltaTime; if (_toastT <= 0 && toastText) toastText.gameObject.SetActive(false); }
        }

        void CoinsChanged(int total) { if (coinsText) coinsText.text = total.ToString(); }
        void ScoreChanged(int s) { if (scoreText) scoreText.text = s.ToString(); }
        void HeartsChanged(int h) { if (heartsText) heartsText.text = new string('❤', Mathf.Max(0, h)); }
        void ComboChanged(int c)
        {
            if (comboText == null) return;
            if (c >= 3) { comboText.gameObject.SetActive(true); comboText.text = "x" + c + " كومبو!"; }
            else comboText.gameObject.SetActive(false);
        }
        void PowerCharge(float m, float s)
        {
            if (magnetBar) magnetBar.fillAmount = m;
            if (starBar) starBar.fillAmount = s;
        }
        void ShowToast(string msg)
        {
            if (toastText == null) return;
            toastText.text = msg;
            toastText.gameObject.SetActive(true);
            _toastT = 1.6f;
        }
    }
}
