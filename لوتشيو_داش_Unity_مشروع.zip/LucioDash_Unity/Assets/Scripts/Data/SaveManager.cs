using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// حفظ/تحميل التقدّم عبر PlayerPrefs (يعمل على الويب والجوال).
    /// </summary>
    public static class SaveManager
    {
        const string K_Coins = "lucio_coins";
        const string K_Best = "lucio_best";
        const string K_Mute = "lucio_mute";
        const string K_Char = "lucio_char";          // الشخصية المختارة
        const string K_Unlock = "lucio_unlocked_";   // بادئة الأشياء المشتراة
        const string K_Magnet = "lucio_magnet_lvl";
        const string K_Star = "lucio_star_lvl";
        const string K_Games = "lucio_games";
        const string K_Tutorial = "lucio_tut";

        public static int Coins { get => PlayerPrefs.GetInt(K_Coins, 0); set => PlayerPrefs.SetInt(K_Coins, Mathf.Max(0, value)); }
        public static int BestScore { get => PlayerPrefs.GetInt(K_Best, 0); set => PlayerPrefs.SetInt(K_Best, Mathf.Max(0, value)); }
        public static bool Muted { get => PlayerPrefs.GetInt(K_Mute, 0) == 1; set => PlayerPrefs.SetInt(K_Mute, value ? 1 : 0); }
        public static int SelectedCharacter { get => PlayerPrefs.GetInt(K_Char, 0); set => PlayerPrefs.SetInt(K_Char, value); }
        public static int MagnetLevel { get => PlayerPrefs.GetInt(K_Magnet, 1); set => PlayerPrefs.SetInt(K_Magnet, Mathf.Max(1, value)); }
        public static int StarLevel { get => PlayerPrefs.GetInt(K_Star, 1); set => PlayerPrefs.SetInt(K_Star, Mathf.Max(1, value)); }
        public static int GamesPlayed { get => PlayerPrefs.GetInt(K_Games, 0); set => PlayerPrefs.SetInt(K_Games, value); }
        public static bool TutorialDone { get => PlayerPrefs.GetInt(K_Tutorial, 0) == 1; set => PlayerPrefs.SetInt(K_Tutorial, value ? 1 : 0); }

        public static bool IsUnlocked(string id)
        {
            return PlayerPrefs.GetInt(K_Unlock + id, 0) == 1;
        }

        public static void Unlock(string id)
        {
            PlayerPrefs.SetInt(K_Unlock + id, 1);
        }

        public static bool TrySpend(int amount)
        {
            if (Coins < amount) return false;
            Coins = Coins - amount;
            return true;
        }

        public static void AddCoins(int amount)
        {
            Coins = Coins + amount;
        }

        public static void Save()
        {
            PlayerPrefs.Save();
        }

        public static void ResetAll()
        {
            PlayerPrefs.DeleteAll();
            PlayerPrefs.Save();
        }
    }
}
