using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// إعدادات اللعبة القابلة للضبط من المحرّر (ScriptableObject).
    /// ينشئها سكربت SceneBuilder تلقائياً في Assets/ScriptableObjects.
    /// </summary>
    [CreateAssetMenu(fileName = "GameConfig", menuName = "Lucio Dash/Game Config", order = 0)]
    public class GameConfig : ScriptableObject
    {
        [Header("المسارات (Lanes)")]
        [Tooltip("عدد المسارات")]
        public int laneCount = 3;
        [Tooltip("العرض بين كل مسار")]
        public float laneWidth = 2.2f;

        [Header("السرعة")]
        public float baseSpeed = 14f;
        public float maxSpeed = 32f;
        [Tooltip("مقدار زيادة السرعة كل ثانية")]
        public float speedRamp = 0.45f;

        [Header("القفز والانزلاق")]
        public float jumpHeight = 2.6f;
        public float jumpDuration = 0.62f;
        public float slideDuration = 0.7f;
        [Tooltip("حجم المصادمة أثناء الانزلاق (نسبة)")]
        public float slideColliderScale = 0.45f;

        [Header("التوليد (Spawning)")]
        [Tooltip("المسافة بين كل صف عوائق")]
        public float spawnGap = 16f;
        public float spawnZ = 90f;
        public float despawnZ = -12f;
        [Tooltip("احتمال صفّين من العوائق معاً")]
        [Range(0, 1)] public float dualObstacleChance = 0.28f;
        [Range(0, 1)] public float powerUpChance = 0.1f;
        [Range(0, 1)] public float arcCoinsChance = 0.35f;
        public int coinsPerRow = 6;

        [Header("القدرات")]
        public float magnetDuration = 6f;
        public float magnetRadius = 3.2f;
        public float starDuration = 7f;

        [Header("الخصم (Krensh)")]
        public float enemyBaseDistance = 9f;
        public float enemyCatchDistance = 1.6f;
        [Tooltip("كم يقترب الخصم عند كل اصطدام")]
        public float enemyApproachOnHit = 2.2f;
        public int maxHearts = 3;

        [Header("الكاميرا")]
        public Vector3 cameraOffsetLandscape = new Vector3(0f, 5.2f, -8.2f);
        public Vector3 cameraOffsetPortrait = new Vector3(0f, 7.2f, -11.6f);
        public float cameraLookAhead = 12f;
        public float cameraLerp = 6f;

        /// <summary>إحداثيات X لمسار معيّن (0-based).</summary>
        public float LaneX(int lane)
        {
            int mid = laneCount / 2;
            return (lane - mid) * laneWidth;
        }

        /// <summary>معايرة كاميرا حسب الاتجاه.</summary>
        public Vector3 CameraOffset(bool portrait)
        {
            return portrait ? cameraOffsetPortrait : cameraOffsetLandscape;
        }
    }
}
