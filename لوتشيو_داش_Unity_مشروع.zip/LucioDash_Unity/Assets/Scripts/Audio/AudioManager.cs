using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// مدير الصوت: مؤثرات صوتية مُولَّدة برمجياً (لا تحتاج ملفات صوت)
    /// + موسيقى خلفية هادئة. يحترم كتم SaveManager.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        const int SR = 44100;
        AudioClip _coin, _jump, _land, _hit, _click, _whoosh, _power, _slide, _step;
        AudioSource _music, _wind;
        AudioSource[] _sfxPool;
        int _sfxIdx;
        float _vol = 0.6f;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            _coin = Tone(880, 0.18f, 0.5f, true);
            _jump = Sweep(220, 560, 0.22f, 0.3f);
            _land = Tone(110, 0.18f, 0.4f, false);
            _hit = Noise(0.22f, 0.5f, 800);
            _click = Tone(660, 0.07f, 0.35f, true);
            _whoosh = Noise(0.18f, 0.25f, 1600);
            _power = Sweep(440, 990, 0.3f, 0.35f);
            _slide = Noise(0.3f, 0.25f, 500);
            _step = Noise(0.08f, 0.18f, 250);

            _sfxPool = new AudioSource[6];
            for (int i = 0; i < _sfxPool.Length; i++)
            {
                var go = new GameObject("sfx" + i);
                go.transform.SetParent(transform);
                _sfxPool[i] = go.AddComponent<AudioSource>();
            }
            _music = gameObject.AddComponent<AudioSource>();
            _wind = gameObject.AddComponent<AudioSource>();
            StartMusic();
            StartWind();
            RefreshMute();
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        public void RefreshMute()
        {
            _vol = SaveManager.Muted ? 0f : 0.6f;
            if (_music) _music.volume = _vol * 0.18f;
            if (_wind) _wind.volume = _vol * 0.06f;
        }

        public void Play(AudioClip c, float vol = 1f)
        {
            if (c == null || _vol <= 0f) return;
            var s = _sfxPool[_sfxIdx]; _sfxIdx = (_sfxIdx + 1) % _sfxPool.Length;
            s.PlayOneShot(c, vol * _vol);
        }

        public void PlayCoin() => Play(_coin, 0.9f);
        public void PlayJump() => Play(_jump, 0.9f);
        public void PlayLand() => Play(_land, 0.8f);
        public void PlayHit() => Play(_hit, 0.9f);
        public void PlayClick() => Play(_click, 0.7f);
        public void PlayWhoosh() => Play(_whoosh, 0.6f);
        public void PlayPower() => Play(_power, 0.9f);
        public void PlaySlide() => Play(_slide, 0.7f);
        public void PlayFootstep() => Play(_step, 0.5f);

        void StartMusic()
        {
            // نغمة متكررة لطيفة (8 ثوانٍ)
            int len = SR * 8;
            var clip = AudioClip.Create("music", len, 1, SR, false);
            var d = new float[len];
            float[] notes = { 261.63f, 329.63f, 392f, 523.25f, 392f, 329.63f };
            for (int i = 0; i < len; i++)
            {
                float t = (float)i / SR;
                float n = notes[(int)(t * 2f) % notes.Length];
                d[i] = Mathf.Sin(t * n * 2f * Mathf.PI) * 0.5f + Mathf.Sin(t * n * 4f * Mathf.PI) * 0.12f;
                d[i] *= 0.6f;
            }
            clip.SetData(d, 0);
            _music.clip = clip; _music.loop = true; _music.volume = _vol * 0.18f; _music.Play();
        }

        void StartWind()
        {
            int len = SR * 2;
            var clip = AudioClip.Create("wind", len, 1, SR, false);
            var d = new float[len];
            for (int i = 0; i < len; i++) d[i] = (Random.value * 2f - 1f) * 0.4f;
            clip.SetData(d, 0);
            _wind.clip = clip; _wind.loop = true; _wind.volume = _vol * 0.06f; _wind.Play();
        }

        // ── مولّدات النغمات ──
        AudioClip Tone(float freq, float dur, float amp, bool sine)
        {
            int len = Mathf.Max(1, Mathf.FloorToInt(SR * dur));
            var clip = AudioClip.Create("t", len, 1, SR, false);
            var d = new float[len];
            for (int i = 0; i < len; i++)
            {
                float t = (float)i / SR;
                float env = 1f - (float)i / len;
                d[i] = (sine ? Mathf.Sin(t * freq * 2f * Mathf.PI) : (Mathf.Sin(t * freq * 2f * Mathf.PI) * 0.6f)) * env * amp;
            }
            clip.SetData(d, 0);
            return clip;
        }

        AudioClip Sweep(float f0, float f1, float dur, float amp)
        {
            int len = Mathf.Max(1, Mathf.FloorToInt(SR * dur));
            var clip = AudioClip.Create("s", len, 1, SR, false);
            var d = new float[len];
            for (int i = 0; i < len; i++)
            {
                float t = (float)i / SR;
                float f = Mathf.Lerp(f0, f1, (float)i / len);
                float env = 1f - (float)i / len;
                d[i] = Mathf.Sin(t * f * 2f * Mathf.PI) * env * amp;
            }
            clip.SetData(d, 0);
            return clip;
        }

        AudioClip Noise(float dur, float amp, float cutoff)
        {
            int len = Mathf.Max(1, Mathf.FloorToInt(SR * dur));
            var clip = AudioClip.Create("n", len, 1, SR, false);
            var d = new float[len];
            float prev = 0f;
            float a = cutoff / SR;
            for (int i = 0; i < len; i++)
            {
                float env = 1f - (float)i / len;
                float white = Random.value * 2f - 1f;
                prev = prev + a * (white - prev); // مرشّح منخفض بسيط
                d[i] = prev * env * amp;
            }
            clip.SetData(d, 0);
            return clip;
        }
    }
}
