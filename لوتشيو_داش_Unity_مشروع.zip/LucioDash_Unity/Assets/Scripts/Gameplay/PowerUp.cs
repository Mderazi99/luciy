using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// قدرة قابلة للالتقاط: مغناطيس أو نجمة.
    /// </summary>
    public class PowerUp : MonoBehaviour
    {
        public bool isMagnet = true;
        public float spinSpeed = 120f;
        public float bobHeight = 0.15f;
        Vector3 _base; float _t;

        void OnEnable() { _t = Random.Range(0f, 6f); _base = transform.position; }

        void Update()
        {
            transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.Self);
            _t += Time.deltaTime * 2.5f;
            var p = transform.position;
            p.y = _base.y + Mathf.Sin(_t) * bobHeight;
            transform.position = p;
        }

        void OnTriggerEnter(Collider other)
        {
            if (!other.CompareTag("Player")) return;
            var gm = GameManager.Instance;
            if (gm == null) return;
            if (isMagnet) gm.AddMagnetCharge(1f); else gm.AddStarCharge(1f);
            if (AudioManager.Instance) AudioManager.Instance.PlayPower();
            if (gm.spawner != null) gm.spawner.DespawnPowerUp(gameObject);
            else
            {
                var p = GetComponent<PooledItem>();
                if (p != null) p.ReturnToPool(); else Destroy(gameObject);
            }
        }
    }
}
