using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// تمرير نسيج الأرضية (إيهام الحركة) + إعادة تدوير الديكور الجانبي.
    /// اللاعب ثابت، لذا نحرّك النسيج والديكور نحوه.
    /// </summary>
    public class GroundScroller : MonoBehaviour
    {
        public Renderer groundRenderer;
        public Transform[] decor;
        public float decorWrapZ = -14f;
        public float decorSpanZ = 80f;
        public float sideOffset = 7f;

        Material _mat;
        float _offset;

        void Awake()
        {
            if (groundRenderer != null) _mat = groundRenderer.material;
        }

        void Update()
        {
            if (GameManager.Instance == null) return;
            float speed = (GameManager.Instance.State == GameState.Playing) ? GameManager.Instance.Speed : GameManager.Instance.config.baseSpeed * 0.25f;
            float dt = Time.deltaTime;

            if (_mat != null)
            {
                _offset += speed * dt * 0.15f;
                _mat.mainTextureOffset = new Vector2(0f, -_offset);
            }

            if (decor != null)
            {
                Vector3 back = Vector3.back * speed * dt;
                for (int i = 0; i < decor.Length; i++)
                {
                    var d = decor[i];
                    if (d == null) continue;
                    d.position += back;
                    if (d.position.z < decorWrapZ)
                    {
                        d.position = new Vector3(d.position.x < 0 ? -sideOffset - Random.Range(0, 5f) : sideOffset + Random.Range(0, 5f),
                                                 d.position.y, d.position.z + decorSpanZ);
                        d.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
                    }
                }
            }
        }
    }
}
