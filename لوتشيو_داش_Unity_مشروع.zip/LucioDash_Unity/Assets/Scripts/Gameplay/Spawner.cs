using System.Collections.Generic;
using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// توليد صفوف لا نهائية: عوائق + عملات + قدرات.
    /// يتحرك كل شيء نحو اللاعب (−Z) ويُعاد للتجمّع عند تجاوزه.
    /// </summary>
    public class Spawner : MonoBehaviour
    {
        public ObjectPooler pooler;
        public Transform worldRoot;            // أب لتنظيم الكائنات (اختياري)

        const string POOL_COIN = "Coin";
        const string POOL_OBS = "Obstacle";
        const string POOL_MAGNET = "Magnet";
        const string POOL_STAR = "Star";

        readonly List<GameObject> _coins = new List<GameObject>();
        readonly List<GameObject> _obstacles = new List<GameObject>();
        readonly List<GameObject> _powers = new List<GameObject>();

        GameConfig _cfg;
        float _distSinceSpawn;

        void Awake()
        {
            _cfg = GameManager.Instance.config;
        }

        void Update()
        {
            if (GameManager.Instance.State != GameState.Playing) return;
            float speed = GameManager.Instance.Speed;
            float dt = Time.deltaTime;

            // تحريك كل شيء نحو اللاعب
            Vector3 back = Vector3.back * speed * dt;
            MoveAndRecycle(_coins, back);
            MoveAndRecycle(_obstacles, back);
            MoveAndRecycle(_powers, back);

            // المغناطيس: جذب العملات القريبة نحو اللاعب
            var pl = GameManager.Instance.player;
            if (GameManager.Instance.MagnetActive && pl != null)
            {
                Vector3 pp = pl.transform.position;
                float r = _cfg.magnetRadius;
                for (int i = 0; i < _coins.Count; i++)
                {
                    var go = _coins[i];
                    if (go == null) continue;
                    Vector3 cp = go.transform.position;
                    if (Mathf.Abs(cp.z - pp.z) < r && Mathf.Abs(cp.x - pp.x) < r)
                    {
                        cp = Vector3.Lerp(cp, pp, Mathf.Clamp01(8f * dt));
                        go.transform.position = cp;
                    }
                }
            }

            // دوران العملات
            Vector3 spin = Vector3.up * (360f * dt);
            for (int i = 0; i < _coins.Count; i++)
            {
                var go = _coins[i];
                if (go != null) go.transform.Rotate(spin, Space.Self);
            }

            // توليد صف جديد كل spawnGap مسافة
            _distSinceSpawn += speed * dt;
            if (_distSinceSpawn >= _cfg.spawnGap)
            {
                _distSinceSpawn = 0f;
                SpawnRow();
            }
        }

        void MoveAndRecycle(List<GameObject> list, Vector3 delta)
        {
            for (int i = list.Count - 1; i >= 0; i--)
            {
                var go = list[i];
                if (go == null) { list.RemoveAt(i); continue; }
                go.transform.position += delta;
                if (go.transform.position.z < _cfg.despawnZ)
                {
                    var pooled = go.GetComponent<PooledItem>();
                    if (pooled != null) pooled.ReturnToPool(); else Destroy(go);
                    list.RemoveAt(i);
                }
            }
        }

        void SpawnRow()
        {
            int lanes = _cfg.laneCount;
            bool dual = Random.value < _cfg.dualObstacleChance;
            int obstacleCount = dual ? 2 : 1;
            var used = new HashSet<int>();

            // عوائق
            for (int n = 0; n < obstacleCount; n++)
            {
                int lane; do { lane = Random.Range(0, lanes); } while (used.Contains(lane));
                used.Add(lane);
                SpawnObstacle(lane);
            }

            // عملات في مسار حر
            var free = new List<int>();
            for (int l = 0; l < lanes; l++) if (!used.Contains(l)) free.Add(l);
            if (free.Count > 0)
            {
                int coinLane = free[Random.Range(0, free.Count)];
                bool arc = Random.value < _cfg.arcCoinsChance;
                for (int i = 0; i < _cfg.coinsPerRow; i++)
                {
                    float y = arc ? 1.2f + Mathf.Sin((float)i / (_cfg.coinsPerRow - 1) * Mathf.PI) * 1.1f : 1.2f;
                    SpawnCoin(coinLane, y, _cfg.spawnZ + i * 1.6f);
                }
                // عملة إضافية في مسار حر آخر
                if (free.Count > 1)
                {
                    int fl = free.Find(l => l != coinLane);
                    SpawnCoin(fl, 1.2f, _cfg.spawnZ);
                }
            }

            // قدرة
            if (Random.value < _cfg.powerUpChance && free.Count > 0)
            {
                int pl = free[Random.Range(0, free.Count)];
                bool magnet = Random.value < 0.5f;
                var id = magnet ? POOL_MAGNET : POOL_STAR;
                var go = pooler.Spawn(id, new Vector3(_cfg.LaneX(pl), 1.4f, _cfg.spawnZ), Quaternion.identity);
                if (go != null)
                {
                    if (worldRoot) go.transform.SetParent(worldRoot, true);
                    _powers.Add(go);
                }
            }
        }

        void SpawnObstacle(int lane)
        {
            var go = pooler.Spawn(POOL_OBS, new Vector3(_cfg.LaneX(lane), 0f, _cfg.spawnZ), Quaternion.identity);
            if (go == null) return;
            if (worldRoot) go.transform.SetParent(worldRoot, true);
            var ob = go.GetComponent<Obstacle>();
            if (ob != null)
            {
                // اختيار نوع عشوائي
                float r = Random.value;
                ob.kind = r < 0.4f ? ObstacleKind.LowJumpable : r < 0.7f ? ObstacleKind.HighSlideable : ObstacleKind.Full;
            }
            _obstacles.Add(go);
        }

        void SpawnCoin(int lane, float y, float z)
        {
            var go = pooler.Spawn(POOL_COIN, new Vector3(_cfg.LaneX(lane), y, z), Quaternion.identity);
            if (go == null) return;
            if (worldRoot) go.transform.SetParent(worldRoot, true);
            _coins.Add(go);
        }

        // القدرة تُلتقط → أعدناها للتجمّع هنا
        public void DespawnPowerUp(GameObject go)
        {
            if (_powers.Remove(go))
            {
                var pooled = go.GetComponent<PooledItem>();
                if (pooled != null) pooled.ReturnToPool(); else Destroy(go);
            }
        }

        /// <summary>إعادة كل الكائنات للتجمّع عند بدء جولة جديدة.</summary>
        public void ClearAll()
        {
            ClearList(_coins); ClearList(_obstacles); ClearList(_powers);
            _distSinceSpawn = 0f;
        }

        void ClearList(List<GameObject> list)
        {
            foreach (var go in list)
            {
                if (go == null) continue;
                var pooled = go.GetComponent<PooledItem>();
                if (pooled != null) pooled.ReturnToPool(); else Destroy(go);
            }
            list.Clear();
        }
    }
}
