using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// عائق: Full (تجنّب المسار) / LowJumpable (اقفز فوقه) / HighSlideable (انزلق تحته).
    /// يكتشف اللاعب ويتصرّف حسب حالته.
    /// </summary>
    public enum ObstacleKind { Full, LowJumpable, HighSlideable }

    public class Obstacle : MonoBehaviour
    {
        public ObstacleKind kind = ObstacleKind.Full;
        [Tooltip("هل يدور؟ (مثلاً منشار/برميل)")]
        public bool spin;
        public float spinSpeed = 180f;
        [Tooltip("هل يطفو/يرتفع وينخفض؟ (كرة شائكة)")]
        public bool bob;
        public float bobHeight = 0.4f;
        public float bobSpeed = 2f;

        Vector3 _basePos; float _t; bool _consumed;

        void OnEnable()
        {
            _consumed = false;
            _basePos = transform.position;
            _t = Random.Range(0f, Mathf.PI * 2f);
        }

        void Update()
        {
            if (spin) transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.Self);
            if (bob) { _t += Time.deltaTime * bobSpeed; transform.position = _basePos + Vector3.up * (Mathf.Sin(_t) * bobHeight); }
        }

        void OnTriggerEnter(Collider other)
        {
            if (_consumed || !other.CompareTag("Player")) return;
            var pc = other.GetComponent<PlayerController>();
            if (pc == null) return;

            bool pass = (kind == ObstacleKind.LowJumpable && pc.IsJumping)
                     || (kind == ObstacleKind.HighSlideable && pc.IsSliding);

            if (pass)
            {
                GameManager.Instance.NearMiss();
            }
            else
            {
                _consumed = true;
                GameManager.Instance.TakeHit();
            }
            ReturnToPool();
        }

        void ReturnToPool()
        {
            var pooled = GetComponent<PooledItem>();
            if (pooled != null) pooled.ReturnToPool();
            else gameObject.SetActive(false);
        }
    }
}
