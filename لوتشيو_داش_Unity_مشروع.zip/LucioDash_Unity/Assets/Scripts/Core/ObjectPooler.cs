using System.Collections.Generic;
using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// تجمّع كائنات عام (Object Pooling) — يُعيد استخدام العملات والعوائق
    /// بدلاً من إنشائها/تدميرها كل إطار، وهو مفتاح الأداء على الجوال.
    /// </summary>
    public class ObjectPooler : MonoBehaviour
    {
        [System.Serializable]
        public class Pool
        {
            public string id;
            public GameObject prefab;
            public int initialSize = 12;
            public int maxSize = 40;
        }

        public List<Pool> pools = new List<Pool>();
        readonly Dictionary<string, Queue<GameObject>> _available = new Dictionary<string, Queue<GameObject>>();
        readonly Dictionary<string, int> _max = new Dictionary<string, int>();
        readonly Dictionary<string, GameObject> _prefab = new Dictionary<string, GameObject>();

        void Awake()
        {
            foreach (var p in pools)
            {
                var q = new Queue<GameObject>();
                _available[p.id] = q;
                _max[p.id] = p.maxSize;
                _prefab[p.id] = p.prefab;
                for (int i = 0; i < p.initialSize; i++) q.Enqueue(CreateNew(p.id));
            }
        }

        GameObject CreateNew(string id)
        {
            var go = Instantiate(_prefab[id]);
            go.SetActive(false);
            go.transform.SetParent(transform, false);
            var pooled = go.GetComponent<PooledItem>();
            if (pooled == null) pooled = go.AddComponent<PooledItem>();
            pooled.Pooler = this;
            pooled.PoolId = id;
            return go;
        }

        /// <summary>طلب كائن من التجمّع (ينمو عند الحاجة).</summary>
        public GameObject Spawn(string id, Vector3 pos, Quaternion rot)
        {
            if (!_available.TryGetValue(id, out var q) || _prefab[id] == null) return null;
            if (q.Count == 0) q.Enqueue(CreateNew(id));
            var go = q.Dequeue();
            go.transform.SetPositionAndRotation(pos, rot);
            go.SetActive(true);
            return go;
        }

        /// <summary>إعادة كائن للتجمّع.</summary>
        public void Despawn(GameObject go)
        {
            var pooled = go.GetComponent<PooledItem>();
            if (pooled == null) { Destroy(go); return; }
            go.SetActive(false);
            if (_available.TryGetValue(pooled.PoolId, out var q)) q.Enqueue(go);
            else Destroy(go);
        }

        int CountActive(string id) => _available.TryGetValue(id, out var q) ? _max[id] - q.Count : 0;
    }

    /// <summary>علامة على الكائن المُجمَّع.</summary>
    public class PooledItem : MonoBehaviour
    {
        public ObjectPooler Pooler;
        public string PoolId;

        public void ReturnToPool()
        {
            if (Pooler != null) Pooler.Despawn(gameObject);
            else Destroy(gameObject);
        }
    }
}
