using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// تحكّم باللاعب: تبديل المسارات، القفز، الانزلاق، الإدخال (لمس/لوحة مفاتيح).
    /// اللاعب ثابت عند z=0 والعالم يتحرك نحوه.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerController : MonoBehaviour
    {
        public Animator animator;
        public ParticleSystem dustPrefab;     // غبار القدمين (اختياري)
        public Transform modelRoot;           // جذر النموذج لإمالته

        GameConfig _cfg;
        Rigidbody _rb;
        int _lane;
        float _targetX, _xVel;
        bool _jumping, _sliding;
        float _jumpT, _slideT, _yBase;

        /// <summary>حالة القفز/الانزلاق (يقرأها مكوّن Obstacle).</summary>
        public bool IsJumping => _jumping;
        public bool IsSliding => _sliding;
        public int CurrentLane => _lane;
        Vector3 _colliderCenter; Vector3 _colliderSize;
        Collider _collider;

        // ── إدخال اللمس ──
        Vector2 _touchStart; bool _touching;
        const float SWIPE_MIN = 60f;

        void Awake()
        {
            _rb = GetComponent<Rigidbody>();
            _cfg = GameManager.Instance.config;
            _collider = GetComponent<Collider>();
            if (_collider is CapsuleCollider c) { _colliderCenter = c.center; _colliderSize = new Vector3(c.radius, c.height, c.radius); }
            else if (_collider is BoxCollider b) { _colliderCenter = b.center; _colliderSize = b.size; }
            _yBase = transform.position.y;
            _lane = _cfg.laneCount / 2;
            _targetX = _cfg.LaneX(_lane);
            transform.position = new Vector3(_targetX, _yBase, 0f);
        }

        void Update()
        {
            if (GameManager.Instance.State != GameState.Playing) return;
            HandleInput();
            UpdateMovement(Time.deltaTime);
        }

        void HandleInput()
        {
            // لوحة المفاتيح (لاختبار المحرّر)
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) ChangeLane(-1);
            else if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) ChangeLane(1);
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space)) Jump();
            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) Slide();

            // اللمس
            if (Input.touchCount > 0)
            {
                var t = Input.GetTouch(0);
                if (t.phase == TouchPhase.Began) { _touchStart = t.position; _touching = true; }
                else if (_touching && (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled))
                {
                    Vector2 d = t.position - _touchStart;
                    if (d.magnitude >= SWIPE_MIN)
                    {
                        if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) ChangeLane(d.x > 0 ? 1 : -1);
                        else if (d.y > 0) Jump(); else Slide();
                    }
                    _touching = false;
                }
            }
#if UNITY_EDITOR || UNITY_STANDALONE
            // ماوس للاختبار
            if (Input.GetMouseButtonDown(0)) { _touchStart = Input.mousePosition; _touching = true; }
            else if (_touching && Input.GetMouseButtonUp(0))
            {
                Vector2 d = (Vector2)Input.mousePosition - _touchStart;
                if (d.magnitude >= SWIPE_MIN)
                {
                    if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) ChangeLane(d.x > 0 ? 1 : -1);
                    else if (d.y > 0) Jump(); else Slide();
                }
                _touching = false;
            }
#endif
        }

        void UpdateMovement(float dt)
        {
            // تبديل المسار بسلاسة
            float x = Mathf.SmoothDamp(transform.position.x, _targetX, ref _xVel, 0.08f, 12f, dt);
            // إمالة النموذج عند التحويل
            if (modelRoot != null)
            {
                float tilt = Mathf.Clamp((_targetX - transform.position.x) * 6f, -18f, 18f);
                modelRoot.localRotation = Quaternion.Slerp(modelRoot.localRotation,
                    Quaternion.Euler(0f, 0f, -tilt), dt * 8f);
            }

            // القفز (قوس قطع مكافئ)
            float y = _yBase;
            if (_jumping)
            {
                _jumpT += dt;
                float p = _jumpT / _cfg.jumpDuration;
                if (p >= 1f) { _jumping = false; y = _yBase; if (animator) animator.SetTrigger("Land"); SpawnDust(); }
                else y = _yBase + 4f * _cfg.jumpHeight * p * (1f - p); // قوس
            }

            // الانزلاق
            if (_sliding)
            {
                _slideT -= dt;
                if (_slideT <= 0f) { _sliding = false; ResetCollider(); if (animator) animator.SetBool("Slide", false); }
            }

            transform.position = new Vector3(x, y, 0f);
            _rb.MovePosition(new Vector3(x, y, 0f));
        }

        public void ChangeLane(int dir)
        {
            int n = Mathf.Clamp(_lane + dir, 0, _cfg.laneCount - 1);
            if (n == _lane) return;
            _lane = n;
            _targetX = _cfg.LaneX(_lane);
            if (animator) animator.SetTrigger("Lane");
        }

        public void Jump()
        {
            if (_jumping || _sliding) return;
            _jumping = true; _jumpT = 0f;
            if (animator) animator.SetTrigger("Jump");
            if (AudioManager.Instance) AudioManager.Instance.PlayJump();
        }

        public void Slide()
        {
            if (_jumping) return;
            _sliding = true; _slideT = _cfg.slideDuration;
            ShrinkCollider();
            if (animator) animator.SetBool("Slide", true);
            if (AudioManager.Instance) AudioManager.Instance.PlaySlide();
        }

        void ShrinkCollider()
        {
            if (_collider is CapsuleCollider c) { c.height *= _cfg.slideColliderScale; c.center *= _cfg.slideColliderScale; }
            else if (_collider is BoxCollider b) { b.size = new Vector3(b.size.x, b.size.y * _cfg.slideColliderScale, b.size.z); b.center *= _cfg.slideColliderScale; }
        }
        void ResetCollider()
        {
            if (_collider is CapsuleCollider c) { c.height = _colliderSize.y; c.center = _colliderCenter; }
            else if (_collider is BoxCollider b) { b.size = _colliderSize; b.center = _colliderCenter; }
        }

        void SpawnDust()
        {
            if (dustPrefab == null) return;
            var p = Instantiate(dustPrefab, transform.position + Vector3.back * 0.3f, Quaternion.identity);
            Destroy(p.gameObject, 1.2f);
        }

        // ── المصادمة ──
        void OnTriggerEnter(Collider other)
        {
            if (!other.CompareTag("Coin")) return;
            var pooled = other.GetComponent<PooledItem>();
            GameManager.Instance.CollectCoin(1);
            if (AudioManager.Instance) AudioManager.Instance.PlayCoin();
            if (pooled != null) pooled.ReturnToPool(); else Destroy(other.gameObject);
        }

        void OnTriggerExit(Collider other)
        {
            // مرور قريب من عائق دون اصطدام مباشر → كومبو/نقاط إضافية
        }

        // مرور قرب عائق (NearMiss) يُكتشف عبر عائق له منطقة أكبر
        public void NearMiss()
        {
            GameManager.Instance.Score += 5;
            if (AudioManager.Instance) AudioManager.Instance.PlayWhoosh();
        }
    }
}
