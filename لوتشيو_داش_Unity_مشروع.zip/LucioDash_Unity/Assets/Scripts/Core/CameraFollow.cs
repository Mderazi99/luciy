using UnityEngine;

namespace LucioDash
{
    /// <summary>
    /// كاميرا خلف اللاعب: تتبع X بسلاسة، وتتكيّف مع الأفقي/العمودي تلقائياً
    /// (نفس فكرة CAM_LAND/CAM_PORT في نسخة Three.js).
    /// </summary>
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public GameConfig config;
        public float shake;

        Camera _cam;
        bool _wasPortrait;

        void Awake()
        {
            _cam = GetComponent<Camera>();
            if (config == null && GameManager.Instance != null) config = GameManager.Instance.config;
            ApplyOrientation();
        }

        void LateUpdate()
        {
            if (target == null) return;
            bool portrait = Screen.height > Screen.width;
            if (portrait != _wasPortrait) { _wasPortrait = portrait; ApplyOrientation(); }

            var off = config.CameraOffset(portrait);
            Vector3 desired = target.position + off;
            desired.x = target.position.x * 0.35f + off.x;
            desired.y += Mathf.Sin(Time.time * 4f) * 0.05f;

            float lerp = config.cameraLerp * Time.deltaTime;
            transform.position = Vector3.Lerp(transform.position, desired, Mathf.Clamp01(lerp));

            // اهتزاز عند الاصطدام
            if (shake > 0.001f)
            {
                transform.position += new Vector3((Random.value - 0.5f) * shake, (Random.value - 0.5f) * shake, 0f);
                shake *= 0.86f;
            }

            Vector3 look = target.position + Vector3.forward * config.cameraLookAhead;
            look.y = 1.4f;
            transform.LookAt(look);
        }

        void ApplyOrientation()
        {
            bool portrait = Screen.height > Screen.width;
            // FOV أوسع في العمودي لرؤية المسار كاملاً
            if (_cam != null) _cam.fieldOfView = portrait ? 76f : 62f;
        }

        public void Punch(float amount) { shake = Mathf.Max(shake, amount); }
    }
}
