using System;
using UnityEngine;

namespace LucioDash
{
    public enum GameState { Menu, Playing, Paused, GameOver }

    /// <summary>
    /// مدير اللعبة المركزي: الحالة، النقاط، السرعة، القلوب، والأحداث.
    /// مفرد (Singleton) — يبقى عبر المشهد. يُنفَّذ أولاً ليكون Instance جاهزاً للآخرين.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("الإعدادات")]
        public GameConfig config;

        [Header("المراجع (يملؤها SceneBuilder)")]
        public PlayerController player;
        public Spawner spawner;
        public EnemyAI enemy;
        public CameraFollow cameraFollow;

        [Header("حالة اللعبة")]
        public GameState State { get; private set; } = GameState.Menu;
        public int Coins { get; private set; }
        public int Score { get; private set; }
        public float Distance { get; private set; }
        public int Hearts { get; private set; }
        public float Speed { get; private set; }
        public bool MagnetActive { get; private set; }
        public bool StarActive { get; private set; }
        public int Combo { get; private set; }
        public float MagnetCharge { get; private set; }
        public float StarCharge { get; private set; }

        // أحداث
        public event Action<GameState> OnStateChanged;
        public event Action<int> OnCoinsChanged;      // الإجمالي (محفوظ + الجلسة)
        public event Action<int> OnScoreChanged;
        public event Action<int> OnHeartsChanged;
        public event Action<int> OnComboChanged;
        public event Action<string> OnToast;           // رسالة عابرة
        public event Action OnRunStart, OnGameOver, OnRevive;
        public event Action<int> OnMilestone;         // كل 100 متر
        public event Action<float, float> OnPowerChargeChanged;  // مغناطيس، نجمة

        int _lastMilestone;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            Speed = config ? config.baseSpeed : 14f;
            Hearts = config ? config.maxHearts : 3;
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        void Update()
        {
            if (State != GameState.Playing || player == null) return;

            // زيادة السرعة تدريجياً
            var cfg = config;
            Speed = Mathf.Min(cfg.maxSpeed, Speed + cfg.speedRamp * Time.deltaTime);

            // المسافة والنقاط
            float move = Speed * Time.deltaTime;
            Distance += move;
            int newScore = Mathf.FloorToInt(Distance * 0.5f + Coins * 5);
            if (newScore != Score) { Score = newScore; OnScoreChanged?.Invoke(Score); }

            // مراحل كل 100 متر
            int ms = Mathf.FloorToInt(Distance / 100f);
            if (ms > _lastMilestone)
            {
                _lastMilestone = ms;
                OnMilestone?.Invoke(ms * 100);
                OnToast?.Invoke("🏁 " + (ms * 100) + " متر!");
            }

            // الخصم يلحق حسب السرعة
            if (enemy != null) enemy.TickChase(Time.deltaTime);

            // قدرات تنتهي بالمؤقت
            TickPowerUps(Time.deltaTime);
        }

        public void StartGame()
        {
            Coins = 0; Score = 0; Distance = 0; Combo = 0; _lastMilestone = 0;
            Speed = config.baseSpeed;
            Hearts = config.maxHearts;
            MagnetActive = StarActive = false;
            MagnetCharge = StarCharge = 0f;
            SaveManager.GamesPlayed = SaveManager.GamesPlayed + 1;
            SetState(GameState.Playing);
            OnRunStart?.Invoke();
            OnCoinsChanged?.Invoke(SaveManager.Coins);
            OnScoreChanged?.Invoke(Score);
            OnHeartsChanged?.Invoke(Hearts);
            OnComboChanged?.Invoke(Combo);
        }

        public void Pause() { if (State == GameState.Playing) SetState(GameState.Paused); }
        public void Resume() { if (State == GameState.Paused) SetState(GameState.Playing); }

        public void GameOver()
        {
            if (State == GameState.GameOver) return;
            SetState(GameState.GameOver);
            if (Score > SaveManager.BestScore) SaveManager.BestScore = Score;
            SaveManager.Save();
            OnGameOver?.Invoke();
            AdMobManager.Instance?.NotifyGameOver();
        }

        public void Revive()
        {
            Hearts = config.maxHearts;
            Combo = 0;
            Speed = Mathf.Max(config.baseSpeed, Speed - 4f);
            if (enemy != null) enemy.ResetDistance();
            SetState(GameState.Playing);
            OnRevive?.Invoke();
            OnHeartsChanged?.Invoke(Hearts);
        }

        public void BackToMenu()
        {
            SetState(GameState.Menu);
        }

        void SetState(GameState s)
        {
            State = s;
            Time.timeScale = (s == GameState.Paused) ? 0f : 1f;
            OnStateChanged?.Invoke(s);
        }

        // ───────────────────────── جمع واصطدام ─────────────────────────
        public void CollectCoin(int amount = 1)
        {
            Coins += amount;
            Combo++;
            SaveManager.AddCoins(amount);
            OnCoinsChanged?.Invoke(SaveManager.Coins);
            OnComboChanged?.Invoke(Combo);
        }

        public void BreakCombo()
        {
            if (Combo > 0) { Combo = 0; OnComboChanged?.Invoke(Combo); }
        }

        public void TakeHit()
        {
            if (StarActive) { BreakCombo(); return; }      // نجمة = حصانة
            Hearts--;
            BreakCombo();
            OnHeartsChanged?.Invoke(Hearts);
            if (Hearts <= 0) { GameOver(); return; }
            if (enemy != null) enemy.ApproachOnHit();
            OnToast?.Invoke("💥 اصطدام!");
        }

        // ───────────────────────── القدرات ─────────────────────────
        float _magnetT, _starT;
        public void ActivateMagnet()
        {
            if (MagnetCharge < 1f || MagnetActive) return;
            MagnetCharge = 0f; OnPowerChargeChanged?.Invoke(MagnetCharge, StarCharge);
            MagnetActive = true;
            _magnetT = config.magnetDuration * (0.6f + SaveManager.MagnetLevel * 0.4f);
            OnToast?.Invoke("🧲 مغناطيس!");
        }
        public void ActivateStar()
        {
            if (StarCharge < 1f || StarActive) return;
            StarCharge = 0f; OnPowerChargeChanged?.Invoke(MagnetCharge, StarCharge);
            StarActive = true;
            _starT = config.starDuration * (0.6f + SaveManager.StarLevel * 0.4f);
            OnToast?.Invoke("⭐ نجمة حماية!");
        }

        public void AddMagnetCharge(float v)
        {
            MagnetCharge = Mathf.Min(1f, MagnetCharge + v);
            OnPowerChargeChanged?.Invoke(MagnetCharge, StarCharge);
        }
        public void AddStarCharge(float v)
        {
            StarCharge = Mathf.Min(1f, StarCharge + v);
            OnPowerChargeChanged?.Invoke(MagnetCharge, StarCharge);
        }

        void TickPowerUps(float dt)
        {
            if (MagnetActive) { _magnetT -= dt; if (_magnetT <= 0) MagnetActive = false; }
            if (StarActive) { _starT -= dt; if (_starT <= 0) StarActive = false; }
        }

        public void QuitGame()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }
    }
}
